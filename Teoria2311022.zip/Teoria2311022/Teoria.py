from bs4 import BeautifulSoup
with open ('Clientes.xml','r') as f:
    data=f.read()
#print(data)
bs_data=BeautifulSoup(data,"xml")
telefonos=bs_data.find_all('telefono')
print(telefonos)
b_name=bs_data.find('cliente',{'ID':'C001'})
print(b_name)
for tag in bs_data.find_all('cliente',{'ID':'C001'}):
    tag['ciudad']="Madrid"
print(bs_data.prettify())