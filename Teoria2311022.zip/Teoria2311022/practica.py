from bs4 import BeautifulSoup
with open('CatalogoProductos.xml','r') as f:
    data=f.read()
bs_data=BeautifulSoup(data,"xml")
for tag in bs_data.find_all('Producto',{'ID':'100001'}):
    tag['Precio']=9.95
print(bs_data.prettify())