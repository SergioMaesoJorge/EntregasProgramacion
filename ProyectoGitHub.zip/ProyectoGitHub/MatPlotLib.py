import matplotlib.pyplot as plt
import pandas as pd
datos=pd.read_csv("casasboston.csv")
df = datos[["RM","CRIM", "MEDV", "TOWN", "CHAS"]]
df.RM.plot.hist()
plt.show()
df.CRIM.plot.hist(bins=100, xlim=(0,20))
plt.show()
df.plot.scatter(x="CRIM", y="MEDV", alpha=0.2)
plt.show()
valor_por_ciudad = df.groupby("TOWN")["MEDV"].mean()
valor_por_ciudad.head(10).plot.barh()
plt.show()
df["VALOR_CUANTILES"] = pd.qcut(df.MEDV, 5)
df.boxplot(column="CRIM", by="VALOR_CUANTILES",
figsize=(8,6))
plt.show()
df.CHAS.value_counts().plot.pie()
plt.show()