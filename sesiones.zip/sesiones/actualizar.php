<?php
include ("header.html")
?>
<h2>Actualizar pedidos</h2>



<?php
include ("footer.html")
?>
