create table colaboradores
(
    id       int          null,
    correo   varchar(100) null,
    password varchar(100) null,
    constraint colaboradores_pk
        primary key (id)
);