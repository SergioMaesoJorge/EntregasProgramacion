<?php
include ("header.html");
require("config.php");
?>
<h2>Eliminar pedidos</h2>



<?php
if(isset($_GET['codigo'])){
foreach($conn->query('select * from pedidos where id='.$_GET['codigo'].'') as $row){
    ?>
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title">Fecha</h5>
            <p class="card-text"> <?php echo($row['fecha_pedido']); ?></p>
        </div>
        <div class="card-body">
            <h5 class="card-title">Nombre del producto</h5>
            <p class="card-text"> <?php echo($row['producto']); ?></p>
        </div>
        <div class="card-body">
            <h5 class="card-title">Unidades</h5>
            <p class="card-text"> <?php echo($row['unidades']); ?></p>
            <form method="post">
                <input type="submit" name="boton" value="Eliminar">
            </form>
        </div>
    </div>
<?php
}
if(isset($_POST['boton'])){
    foreach($conn->query('delete from pedidos where id='.$_GET['codigo'].'') as $row){

    }
    header("location:consultar.php");

}
}
else{
    header("location:consultar.php");
}
include ("footer.html");
?>