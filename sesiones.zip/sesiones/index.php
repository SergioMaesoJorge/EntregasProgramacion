<?php
include ("header.html")
?>
<h2>Página principal</h2>



<?php
include ("footer.html")
?>