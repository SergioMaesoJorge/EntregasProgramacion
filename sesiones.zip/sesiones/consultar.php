<?php
include ("header.html");
require("config.php");
?>
<h2>Listado de pedidos</h2>
<?php
try{
    echo("<table>");
    echo("<tr><th>Fecha</th><th>Nombre</th><th>Unidades</th><th>Eliminar</th></tr>");
    foreach($conn->query('select * from pedidos') as $row){
        $id=$row['id'];
        echo("<tr><td>");
        echo($row['fecha_pedido']." ");
        echo("</td>");
        echo("<td>");
        echo($row['producto']." ");
        echo("</td>");
        echo("<td>");
        echo($row['unidades']." ");
        echo("</td>");
        echo("<td>");
        echo("<a href='eliminar.php?codigo=".$row['id']."'><ion-icon name='trash-outline'><input type='button' value='$id'></ion-icon></a>");
        echo("</td></tr>");
    }
    echo("</table>");
    $conn= NULL;
} catch (PDOException $e){
    print("Error");
    die();
}
include ("footer.html")
?>
