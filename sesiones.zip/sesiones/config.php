<?php
$host="localhost";
$user="root";
$password="";
$db="testing";
$conn=new PDO('mysql:host='.$host.';dbname='.$db.'',$user,$password);